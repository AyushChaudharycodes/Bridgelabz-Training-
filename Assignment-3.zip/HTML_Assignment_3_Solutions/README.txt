HTML Assignment 3 - Solutions

This folder contains 15 separate HTML files, one for each question in the assignment PDF.

How to use:
1. Extract the ZIP file.
2. Open the folder.
3. Double-click any Qxx_*.html file to open it in a web browser.
4. Open the file in a code editor (such as VS Code) to view or edit the HTML.

Notes:
- The assignment requests HTML only, so no CSS or JavaScript files are included.
- Replace sample contact details, school/college names, and example news links with your own details if required.
- Images in the product and travel pages use placeholder image URLs and need an internet connection to load.
